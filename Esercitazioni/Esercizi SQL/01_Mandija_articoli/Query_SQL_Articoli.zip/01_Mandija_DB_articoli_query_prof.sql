/*
Selezionare gli autori che hanno stipendio maggiore o uguale a 2000
Selezionare gli articoli che iniziano per 'M'
Selezionare gli autori che sono professori
In che sede lavora la Moscarini?
Si vuole sapere il costo della rivista dove è pubblicato l’articolo "Database"
Selezionare titolo e autore, con la descrizione della propria qualifica, di chi ha scritto "Macchine e teoria"
Selezionare titolo e autore, con la descrizione della propria qualifica, di tutti quelli che hanno scritto articoli
Selezionare titolo e autore, con la descrizione della propria qualifica, di tutti quelli che hanno scritto articoli, riportando anche la sede dell’autore e il costo della rivista dove sono stati pubblicati (combinazione dei precedenti)
Visualizzare la media dei costi delle riviste
Calcolare lo stipendio massimo, quello minimo e la media degli stipendi degli autori
Selezionare il Massimo e il minimo stipendio degli autori per ogni dipartimento, con la descrizione del dipartimento
Selezionate nomi, data, descrizione dipartimento e sede degli autori dei dipartimenti 10 e 20 ordinandoli
Contare il numero di autori presenti in ogni dipartimento, suddivisi per città di nascita
Selezionate gli autori, con la loro città di nascita e lo stipendio, che hanno lo stipendio maggiore di quello di "Calzolari"
Visualizzare gli autori che hanno la stessa qualifica di "Calzolari"
Visualizzare gli autori che scrivono sulle stesse riviste (non una sola) dove scrive la Moscarini
Nome degli autori con salario Massimo (non solo uno)
Visualizzare, per ogni dipartimento, gli autori che prendono, in ogni dipartimento, il salario massimo, riportando la descrizione del dipartimento
Selezionare gli autori,con irispettivi salari, che prendono un salario maggiore del più alto salario del dipartimento 20
Si vuole sapere la sede e la media dei salari di ogni dipartimento
Visualizzare titoli e riviste, con editore,su cui si è pubblicato da una certa data ad un'altra
Visualizzare, per ogni nome di dipartimento, su quali riviste si è pubblicato
Contare il numero di autori afferenti ad ogni dipartimento e visualizzarneil totale
*/